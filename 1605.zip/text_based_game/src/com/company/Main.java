package com.company;

import static com.company.view.IOView.mainLoopView;

public class Main {

    public static void main(String[] args) {
        mainLoopView();

    }
}